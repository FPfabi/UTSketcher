let mysvg = canvas.toSVG();
return mysvg;