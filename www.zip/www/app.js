var canvas = null; 

//
// Define database
//
var db = new Dexie("sketchDB");

let color_picker = null;

var color_mode = "next";  // "next" or "selection"
var color_type = "line";  // "line" or "fill"
var default_fill_color = null;  // will be set by colors:pick event

var saved_image_lst = [];
var arr_chain_obj = [];  //objects to group together are collected here
var chain_mode = "finished";  // add, finished

var zoom_inc = null;

var saved_img_max_id = null;
var loaded_img_cur_id = null;

var canvas_dimensions = null;
var canvas_grid_number = 10;
var canvas_grid_number_increment = 2;
var canvas_grid_distance = 0.01;



//custome properties: fh_id, 
// fh_type: "mdist", "ml", "mw", "grid": measure distance, length, width, grid horizontal and vertical lines
// fh_subtype: hmin, hmax, vmin, vmax, angle: horizontal between taking the min, horizontal between taking the max, ...
// fh_source: id of source object
// fh_target: id of target object
var fabric_global_index = -1;


function clear_saved_images(){
    saved_image_lst = [];
}
function add_saved_image(imgpath){
    saved_image_lst.push(imgpath);
    return ("JS: added image to array: " + imgpath);
}


function init_canvas(){
    //set custom handler sizes
    //Does not work: fabric.Object.prototype.cornerSize = 200;

    canvas = new fabric.Canvas("canvas");

    // Overwrite the fabric ownDefaults --> this works
    fabric.InteractiveFabricObject.ownDefaults = {
        ...fabric.InteractiveFabricObject.ownDefaults,
        cornerSize: 70,
        touchCornerSize: 70,
        padding: 10,
        //backgroundColor: '#f0f8ff',
        //preserveObjectStacking: true
    }

    // Adding custom properties to fabric.js objects
    // 
    const originalToObject = fabric.Object.prototype.toObject;
    const myAdditional = ['fh_type'];
    fabric.Object.prototype.toObject = function (additionalProperties) {
        return originalToObject.call(this, myAdditional.concat(additionalProperties));
    }

    // Overwriting toSVG method to get inline SVG objects with embedded images
    fabric.Image.prototype.getSvgSrc = function() {
        return this.toDataURLforSVG();
    };

    fabric.Image.prototype.toDataURLforSVG = function(options) {
        var el = fabric.util.createCanvasElement();
        el.width  = this._element.naturalWidth || this._element.width;
        el.height = this._element.naturalHeight || this._element.height;
        el.getContext("2d").drawImage(this._element, 0, 0);
        var data = el.toDataURL(options);
        return data;
    };

    //enable fabians custom unique object IDs
    canvas.on('object:added', function(e) {
        e.target.fh_id = getnextID();
    });

    //enable zoom events
    canvas.on('mouse:wheel', function(opt) {
        var delta = opt.e.deltaY;
        var zoom = canvas.getZoom();
        zoom *= 0.999 ** delta;
        if (zoom > 20) zoom = 20;
        if (zoom < 0.01) zoom = 0.01;
        canvas.zoomToPoint({ x: opt.e.offsetX, y: opt.e.offsetY }, zoom);
        opt.e.preventDefault();
        opt.e.stopPropagation();
    });
    canvas.on('mouse:down', function(opt) {
        var evt = opt.e;
        if (evt.altKey === true) {
            this.isDragging = true;
            this.selection = false;
            this.lastPosX = evt.clientX;
            this.lastPosY = evt.clientY;
        }
    });
    canvas.on('mouse:move', function(opt) {
        if (this.isDragging) {
            var e = opt.e;
            var vpt = this.viewportTransform;
            vpt[4] += e.clientX - this.lastPosX;
            vpt[5] += e.clientY - this.lastPosY;
            this.requestRenderAll();
            this.lastPosX = e.clientX;
            this.lastPosY = e.clientY;
        }
    });
    canvas.on('mouse:up', function(opt) {
        // on mouse up we want to recalculate new interaction
        // for all objects, so we call setViewportTransform
        this.setViewportTransform(this.viewportTransform);
        this.isDragging = false;
        this.selection = true;
    });

    // for grouping elements we have to detect when an object is selected
    canvas.on({
        'selection:updated': handle_canvas_selection,
        'selection:created': handle_canvas_selection
    });

    
    //init brushes
    canvas.freeDrawingBrush = new fabric.PencilBrush(canvas);


    const helloWorld = new fabric.FabricText('Hello world!');
    canvas.add(helloWorld);
    canvas.centerObject(helloWorld);
    canvas.setActiveObject(helloWorld);

    window.addEventListener('resize', resizeCanvas, false);

    function resizeCanvas() {
        canvas.setDimensions({width:window.innerWidth, height:window.innerHeight-450});
        canvas.renderAll();
        canvas_dimensions = [canvas.getWidth(), canvas.getHeight()]
        return canvas_dimensions;
    }

    // resize on init
    resizeCanvas();

    addRectangle();

}

//Todo: Test this function
// Only load svgs to array and show them on the context menu
function import_json_emoji(json_content){
    for(var i=0; i<json_content.length; i++){
        let svg_obj = json_content[i];
        let svg_image = svg_obj.svg;
        let obj = fabric.util.groupSVGElements(svg_image, null);
        canvas.add(obj).renderAll();
    }
}


// Convert external image to base64 and add to canvas
function addImageFromURL(url) {
    toDataURL(url, function(dataUrl) {
        fabric.Image.fromURL(dataUrl, function(img) {
            canvas.add(img);
            canvas.renderAll();
        });
    });
}

function toDataURL(url, callback) {
    var xhr = new XMLHttpRequest();
    xhr.onload = function() {
        var reader = new FileReader();
        reader.onloadend = function() {
            callback(reader.result);
        }
        reader.readAsDataURL(xhr.response);
    };
    xhr.open('GET', url);
    xhr.responseType = 'blob';
    xhr.send();
}


function zoom_in(){
    var zoom = canvas.getZoom();
    if(zoom_inc == null){
        zoom_inc = 0.5*zoom;
    }

    zoom += zoom_inc;
    try{
        //If center point of active object fails, default to normal zoom
        let ct = canvas.getActiveObject().getCenterPoint();
        canvas.zoomToPoint({ x: ct.x, y: ct.y }, zoom);
    }catch(error){
        canvas.setZoom(zoom);
    }
}

function zoom_out(){
    var zoom = canvas.getZoom();
    if(zoom_inc == null){
        zoom_inc = 0.5*zoom;
    }
    zoom -=zoom_inc;
    try{
        //If center point of active object fails, default to normal zoom
        let ct = canvas.getActiveObject().getCenterPoint();
        canvas.zoomToPoint({ x: ct.x, y: ct.y }, zoom);
    }catch(error){
        canvas.setZoom(zoom);
    }
}

function handle_canvas_selection(){
    if(chain_mode == "add"){
        let obj = canvas.getActiveObject();
        arr_chain_obj.push(obj);
        showToast("Added object, now: " + arr_chain_obj.length.toString())
    }
}

function getnextID(){
    if(fabric_global_index < 0){
        console.log("Start indexing fabric objects from 0");
        fabric_global_index = 0
    }else{
        fabric_global_index+=1;
        console.log("Next object index is: " + fabric_global_index);
    }
    return fabric_global_index;
}

function addRectangle(){
    var rectangle = new fabric.Rect({
            width: 300,
            height: 200,
            fill: 'red',
            stroke: 'black',
            strokeWidth: 3
        });

    // Render the Rect in canvas
    canvas.add(rectangle);
    canvas.centerObject(rectangle);
    canvas.setActiveObject(rectangle);
}

function addVLine(){
    
    let x1 = canvas_dimensions[0]/2;
    let x2 = canvas_dimensions[0]/2;
    let y1 = 0;
    let y2 = canvas_dimensions[1]/2;

    canvas.add(new fabric.Line([x1, y1, x2, y2], {
        left: canvas_dimensions[0]/3,
        top: canvas_dimensions[1]/3,
        stroke: 'black',
        strokeWidth: 3
    }));
}

function changeText(){
    let newtext = document.getElementById("edit_text_input").value;
    try{
        let text_obj = canvas.getActiveObject();
        text_obj.set("text", newtext);
        canvas.renderAll();
    }catch(error){
        console.error("Changing text failed: " + error);
    }
}



function show_popup_form_edit_text(){
    document.getElementById("frm_edit_text").style.display = "block";
}
function hide_popup_form_edit_text(){
    document.getElementById("frm_edit_text").style.display = "none";
}

function addCircle(){
    var circle = new fabric.Circle({
        radius: 50,
        fill: '',
        stroke: 'green',
        strokeWidth: 6
    });

    // Render the Rect in canvas
    canvas.add(circle);
    canvas.centerObject(circle);
    canvas.setActiveObject(circle);
}

function addTriangle(){
    // Create a triangle object
      var triangle = new fabric.Triangle({
         left: 55,
         top: 60,
         width: 250,
         height: 180,
         fill: "orange",
      });

      // Render the Rect in canvas
    canvas.add(triangle);
    canvas.centerObject(triangle);
    canvas.setActiveObject(triangle);
}

function add_dummy_text(){
    const helloWorld = new fabric.FabricText('Hello world!');
    canvas.add(helloWorld);
    canvas.centerObject(helloWorld);
    canvas.setActiveObject(helloWorld);
}

function showMessage(msgtext){
    alert(msgtext);
}

function txt_toggle_bold(){
    //Assume the selected element is a fabrix text
    try{
        let text_obj = canvas.getActiveObject();
        let bold = (text_obj.get("fontWeight") == "bold");
        if(bold){
            text_obj.set("fontWeight", "normal");
        }else{
            text_obj.set("fontWeight", "bold");
        }
        canvas.renderAll();
    }catch(error){
        console.error("Changing text failed: " + error);
    }
}
function txt_toggle_italic(){

}
function txt_larger(){

}
function txt_smaller(){
    
}

function move_down(){
    canvas.sendObjectBackwards(canvas.getActiveObject());
}

function move_down_fully(){
    canvas.sendObjectToBack(canvas.getActiveObject(), true); 
}
function move_up(){
    canvas.bringObjectForward(canvas.getActiveObject());

}
function move_up_fully(){
    canvas.bringObjectToFront(canvas.getActiveObject(), true);
}

function start_brush(){
    color_type = "line";
    color_mode = "next";
    setupBrush();
    canvas.isDrawingMode = true;
}
function stop_brush(){
    canvas.isDrawingMode = false;    
}

function brush_dia_larger(){
    canvas.freeDrawingBrush.width +=1;
}
function brush_dia_smaller(){
    canvas.freeDrawingBrush.width -=1;    
}

function setupBrush(){
    var vLinePatternBrush = new fabric.PatternBrush(canvas);
    vLinePatternBrush.getPatternSrc = function () {
      var patternCanvas = fabric.getEnv().document.createElement('canvas');
      patternCanvas.width = patternCanvas.height = 10;
      var ctx = patternCanvas.getContext('2d');

      ctx.strokeStyle = this.color;
      ctx.lineWidth = 10;
      ctx.beginPath();
      ctx.moveTo(0, 5);
      ctx.lineTo(10, 5);
      ctx.closePath();
      ctx.stroke();

      return patternCanvas;
    };
}

function canvas_delete_selected(){
    try{
        canvas.remove(canvas.getActiveObject());
    }catch (error) {
        console.error(error);
    }
}


function chain_start(){
    canvas.discardActiveObject();
    canvas.renderAll();
    arr_chain_obj = [];
    chain_mode = "add";
    showToast("Click the objects to group");
}

function chain_finish(){
    chain_mode = "finished";
    var group = new fabric.Group(arr_chain_obj);
    canvas.add(group);

    arr_chain_obj.forEach(function(object) {
        canvas.remove(object);  
    });

  canvas.setActiveObject(group);
  canvas.renderAll();
}

function chain_break(){
    var activeObject = canvas.getActiveObject();
    if(activeObject.type=="group"){
        var items = activeObject._objects;
        canvas.remove(activeObject);
        for(var i = 0; i < items.length; i++) {
          canvas.add(items[i]);
          canvas.item(canvas.size()-1).hasControls = true;
        }
        canvas.renderAll();
    }
}


function importImage(imgpath){
    console.log("app.js importImage path: " + imgpath);

    //New method with data url
    /**
    addImageFromURL(imgpath);
    return;
    */

    try{
        var imgObj = new Image();
        imgObj.src = imgpath;
        imgObj.onload = function () {
            var image = new fabric.Image(imgObj);
            image.set({
                    angle: 0,
                    padding: 10,
                    cornersize:10,
            });
            // Using the scaleToWidth method
            image.scaleToWidth(200, false);
            canvas.centerObject(image);
            canvas.add(image);
            canvas.setActiveObject(image);
            canvas.renderAll();
        }
    }catch (error) {
        console.error(error);
    }
}


function showColorPicker(){
  if(color_picker==null){
    color_picker = init_color_picker();
  }
  color_picker.open();
  fix_color_picker_height();
}

function fix_color_picker_height(){
  //fix color picker on mobile
  var elements = document.querySelectorAll('.cp_swatch');
  for(var i=0; i<elements.length; i++){
      elements[i].style.height = "5vh";
      elements[i].style.width = "5vh";
  }
  var elements = document.querySelectorAll('cp_dialog cp_open');
  for(var i=0; i<elements.length; i++){
      elements[i].style.width = "50vh";
  }
  
}

function change_color(colorString){
    try{
        canvas.getActiveObject().set("color", colorString);
    }catch (error) {
        console.error(error);
    }
    canvas.freeDrawingBrush.color = colorString;
}

function change_fill_color(colorString){
    try{
        canvas.getActiveObject().set("fill", colorString);
    }catch (error) {
        console.error(error);
        default_fill_color = colorString;
        color_mode = "next";
    }
}

function canvas_reset_position(){
    // Reset the canvas position and scale
    canvas.setViewportTransform([1, 0, 0, 1, 0, 0]); // [scaleX, skewX, skewY, scaleY, translateX, translateY]
    canvas.renderAll();
}

function init_color_picker(){
    // Turn a <button> element into a ColorPicker
    color_picker = new ColorPicker('#colorPickerImage', {
    headless: true,
    swatchesOnly: true,
    swatches: [
        '#d95d5d', 
        '#db8525', 
        '#e8c43c', 
        '#bed649', 
        '#9ecbdb', 
        '#6399a5', 
        '#c771a1',
        '#264653',
        '#2a9d8f',
        '#e9c46a',
        'rgb(244,162,97)',
        '#e76f51',
        '#d62828',
        'navy',
        '#07b',
        '#0096c7',
        '#00b4d880',
        'rgba(0,119,182,0.8)'
    ],
    });


    //bind events
    color_picker
      .on('open', () => { console.log('colorpicker open') })
      .on('opened', () => { console.log('colorpicker opened') })
      .on('close', () => { console.log('colorpicker close') })
      .on('closed', () => { console.log('colorpicker closed') })
      .on('pick', (color) => {
        if (!color) { 
          return console.log('Color cleared') 
        }
        console.log(
          'Color picked', 
          color.toString(), 
          color.string('hex'), 
          color.string('rgb'), 
          color.string('hsv'), 
          color.string('hsl')
        );

        if(color_type.includes("line")){
            change_color(color.toString());
        }else if(color_type.includes("fill")){
            change_fill_color(color.toString());
        }

      })

    return color_picker;
}



function init_db(){

    db.version(1).stores({
        sketches: '++id, name, content'
    });
    log ("Using Dexie v" + Dexie.semVer);

    //
    // Query Database
    //
    db.open().then(function(){
        //return db.sketches.add({name: "Foo", content: getDummySVG()});
    }).then(function(){

        return db.sketches
            .where('id')
            .between(0,100)
            .toArray();

    }).then(function(sketches){
        //log("Found sketches: " + JSON.stringify(sketches, null, 2));
        console.log("dexie.js database loaded");
    });
}



//using dexie.js
async function addImage(name, content) {
  await db.sketches.add({
    name,
    content
  });

  getLastImage();

  showToast("Image added to library");
}
async function updateImage(name, content) {
  await db.sketches.update({
    name,
    content
  });
}
async function findImage(name, {exactMatch}) {
  query = exactMatch ?
    db.songs.where('name').equals(title) :
    db.songs.where('title').startsWithIgnoreCase(title);
  return await query.toArray();
}
async function getAllImages() {
  return await db.table("sketches").toArray();
}

// Function to get the entry with the highest index
async function getLastImage() {
    const highestEntry = await db.sketches.orderBy('id').last();
    console.log("Highest entry id: " + highestEntry.id);
    saved_img_max_id = highestEntry.id;
    loaded_img_cur_id = saved_img_max_id;
    return highestEntry;
}
async function db_get_previous_img() {
    loaded_img_cur_id-=1;
    if(loaded_img_cur_id < 0){
        loaded_img_cur_id = 0;
    }

    const curEntry = await db.sketches.where({"id": loaded_img_cur_id}).first();
    console.log("Found entry with id: " + curEntry.id);
    return curEntry;
}
async function db_get_next_img() {
    loaded_img_cur_id+=1;
    if(loaded_img_cur_id > saved_img_max_id){
        loaded_img_cur_id = saved_img_max_id;
    }

    const curEntry = await db.sketches.where({"id": loaded_img_cur_id}).first();
    console.log("Found entry with id: " + curEntry.id);
    return curEntry;
}

//Take array of objects
async function deserialize_image(jsonObject){
    canvas.clear();

    await  canvas.loadFromJSON(jsonObject);
    canvas.renderAll();
    console.log("Deserialization complete");
}

function qml_load_last_image(){
    // Usage
    getLastImage().then(entry => {
        console.log("qml_load_last_image - id: " +  entry.id);
        deserialize_image(entry.content);
        get_max_fabric_id();
        showToast("Loaded last image");
    }).catch(error => {
        console.error("Error fetching the entry:", error);
    });
}

function get_max_fabric_id(){
    console.log("Function empty; needs to get max. fabric object id after image was loaded from database");
}

function qml_load_previous_image(){
    db_get_previous_img().then(entry => {
        console.log("qml_load_last_image - id: " +  entry.id);
        deserialize_image(entry.content);
        get_max_fabric_id();
        showToast("Loaded previous image");
    }).catch(error => {
        console.error("Error fetching the entry:", error);
    });

}
function qml_load_next_image(){
    db_get_next_img().then(entry => {
        console.log("qml_load_last_image - id: " +  entry.id);
        deserialize_image(entry.content);
        get_max_fabric_id();
        showToast("Loaded next image");
    }).catch(error => {
        console.error("Error fetching the entry:", error);
    });
}


async function export_png(){
    download_scan();
}


//Called from QML
function qml_image_save(){
    let cont = canvas.toJSON(['fh_type']);  //Todo: Add custom properties here
    console.log("------ SAVING SERIALIZED CONTENT ------------");
    //console.log(cont);
    addImage("test", cont);
}

function getDummySVG(){
    return '"<svg height="220" width="500" xmlns="http://www.w3.org/2000/svg"><polygon points="100,10 150,190 50,190" style="fill:lime;stroke:purple;stroke-width:3" />Sorry, your browser does not support inline SVG.</svg>"'
}
function log(txt) {
    console.log("Dexie log: " + txt);
}

function exportSVG(){
    return canvas.toSVG();
}

function download_scan() {
      console.log('Downlaoding scan')
      let a = document.createElement('a')
      let dt = this.canvas.toDataURL({
        format: 'png',
        quality: 1,
      })
      dt = dt.replace('/^data:image\/[^;]*/', 'data:application/octet-stream')
      dt = dt.replace("'/^data:application\/octet-stream/, 'data:application/octet-stream;headers=Content-Disposition%3A%20attachment%3B%20filename=Canvas.png'")

      a.href = dt
      a.download = 'canvas.png'
      a.click()
}


function showToast(toast_text){
  Toastify({text: toast_text,  gravity: "bottom", offset: {
      x: 0, // horizontal axis - can be a number or a string indicating unity. eg: '2em'
      y: 50 // vertical axis - can be a number or a string indicating unity. eg: '2em'
  }}).showToast();
}


function drawGrid(){
    let cd_width = canvas_dimensions[0];
    let cd_height = canvas_dimensions[1];

    let arrLines = [];
    
    const canvasSize = Math.min(cd_width, cd_height);
    const canvas_grid_distance = canvasSize / canvas_grid_number;
    
    // Vertical
    for (var i = 0; i < (cd_width / canvas_grid_distance); i++) {
        const vGridLine = new fabric.Line(
        [ i * canvas_grid_distance, 0, i * canvas_grid_distance, cd_height],
            {
                evented: false,
                selectable: false,
                stroke: '#ccc'
            }
        );	            
        //canvas.add(vGridLine);
        arrLines.push(vGridLine);
    }

    // Horizontal
    for (var i = 0; i < (cd_height / canvas_grid_distance); i++) {
        const hGridLine = new fabric.Line(
            [ 0, i * canvas_grid_distance, cd_width, i * canvas_grid_distance],
            {
                evented: false,
                selectable: false,
                stroke: '#ccc'
            }
        );
        //canvas.add(hGridLine);
        arrLines.push(hGridLine)
    }

    var gridGroup = new fabric.Group(arrLines);
    gridGroup["fh_type"] = "grid"; // custom property
    gridGroup.selectable = false;

    /*
    gridGroup.toObject = (function(toObject) {
        return function() {
            return fabric.util.object.extend(toObject.call(this), {
            fh_type: this.fh_type
            });
        };
    })(gridGroup.toObject);
    */


    canvas.add(gridGroup);
    canvas.sendObjectToBack(gridGroup, true); 

    canvas.on('object:moving', (options) => { 
        if(canvas_grid_distance > 0){
            options.target.set({
                left: Math.round(options.target.left / canvas_grid_distance) * canvas_grid_distance,
                top: Math.round(options.target.top / canvas_grid_distance) * canvas_grid_distance
            });
        }else{
            options.target.set({
                left: left,
                top: top
            });
        }
    });
}

function deleteGrid(){
    //Now that no grid is visible reduce grid size to almost zero
    canvas_grid_distance = -1;

    canvas.getObjects().forEach(obj => {
    if (obj.fh_type === 'grid') {
        console.log('Grid Group found:', obj);
        canvas.remove(obj);
    }
    });
}

function gridPlus(){
    canvas_grid_number -= canvas_grid_number_increment;
    canvas_grid_number = Math.max(4, canvas_grid_number);
    deleteGrid();
    drawGrid();
}

function gridMinus(){
    canvas_grid_number += canvas_grid_number_increment;
    canvas_grid_number = Math.min(20, canvas_grid_number);
    deleteGrid();
    drawGrid();
}