function setupMenu(ctx){
    const menu = document.getElementById('context-menu');
    menu.innerHTML = '';

    stop_brush();

    switch(ctx) {
    case "ctx_shape":
        add_ctx_item("addRectangle();", "img/rectangles.svg");
        add_ctx_item("addCircle();", "img/circle.svg");
        add_ctx_item("addTriangle();", "img/triangle.svg");
        break;
    case "ctx_text":
        // code block
        add_ctx_item("add_dummy_text();", "img/text.svg");
        add_ctx_item("show_popup_form_edit_text();", "img/text_type.svg");
        add_ctx_item("txt_toggle_bold();", "img/bold.svg");
        add_ctx_item("txt_toggle_italic();", "img/italic.svg");
        add_ctx_item("txt_larger();", "img/plus.svg");
        add_ctx_item("txt_smaller();", "img/minus.svg");
        break;
    case "ctx_brush":
        start_brush();
        add_ctx_item("start_brush();", "img/play.svg");
        add_ctx_item("stop_brush();", "img/stop.svg");
        add_ctx_item("brush_dia_larger();", "img/plus.svg");
        add_ctx_item("brush_dia_smaller();", "img/minus.svg");
        add_ctx_item("showColorPicker();", "img/color-palette.svg");
        break;
    case "ctx_layers":
        add_ctx_item("move_down();", "img/down.svg");
        add_ctx_item("move_down_fully();", "img/down-fully.svg");
        add_ctx_item("move_up();", "img/up.svg");
        add_ctx_item("move_up_fully();", "img/up-fully.svg");
        break;
    case "copypaste":
        add_ctx_item("Copy();", "img/copy.svg");
        add_ctx_item("Paste();", "img/paste.svg");
        break;
    case "ctx_chain":
        add_ctx_item("chain_start();", "img/chain.svg");
        add_ctx_item("chain_finish();", "img/finish.svg");
        add_ctx_item("chain_break();", "img/chain-red.svg");
        break;
    case "ctx_grid":
        add_ctx_item("drawGrid();", "img/grid-new.svg");
        add_ctx_item("gridPlus();", "img/plus.svg");
        add_ctx_item("gridMinus();", "img/minus.svg");
        add_ctx_item("deleteGrid();", "img/grid-delete.svg");
        break;
    case "ctx_settings":
        add_ctx_item("canvas.clear();", "img/new-sketch.svg");
        add_ctx_item("export_png();", "img/download.svg");
        break;
    case "ctx_navigate":
        add_ctx_item("zoom_in();", "img/zoom-in.svg");
        add_ctx_item("zoom_out();", "img/zoom-out.svg");
        add_ctx_item("canvas_reset_position();", "img/fit-canvas.svg");
        break;
    case "ctx_emoji":
        for(var index=0; index<svgs.length; index++){
            let id = svgs[index].id;
            let emojipath = "emoji/" + id + ".svg";
            let emojipath_png = "emoji/" + id + ".png";

            let cmd = "importImage('" + emojipath_png + "');";

            add_ctx_item(cmd, emojipath, id);
        }
        break;
    default:
        // code block
        alert(ctx + " is not implemented!");
    } 
}

function add_svg_from_string(svg_index){
    let svg_string = svgs[svg_index].svg;
    fabric.loadSVGFromString(svg_string).then((result)=>{
        canvas.add(...(result.objects.filter((obj)=> !!obj))).renderAll();
    })

}


function add_svg_from_image(img_id){
    try{
        const imgElement = document.getElementById(img_id);
        
        const imgInstance = new fabric.Image(imgElement, {
            left: canvas_dimensions[0]/3,
            top: canvas_dimensions[1]/3,
            angle: 0
        });
        canvas.add(imgInstance);
        canvas.centerObject(imgInstance);
        canvas.renderAll();
        

        var imgObj = new Image(imgElement);
        //imgObj.src = imgpath;
        imgObj.onload = function () {
            var image = new fabric.Image(imgObj);
            image.set({
                    angle: 0,
                    padding: 10,
                    cornersize:10,
            });
            // Using the scaleToWidth method
            image.scaleToWidth(200, false);
            canvas.centerObject(image);
            canvas.add(image);
            canvas.setActiveObject(image);
            canvas.renderAll();
        }
        showToast("SVG imag added!");
    }catch (error) {
        console.error(error);
        showToast(error);
    }
}


function clear_ctx_menu(){
    document.getElementById('context-menu').innerHTML = '';
}

function eval_fabric(evt){
    eval(evt.currentTarget.cmdstr);
}

//cmdstr: Will be evaluated by eval
//iconpath: /img/path_to_ico
function add_ctx_item(cmdstr, iconpath, img_id = null){
    const menu = document.getElementById('context-menu');
    
    let a = document.createElement('a');
    a.classList.add("icon");
    a.cmdstr = cmdstr;
    a.addEventListener("click", eval_fabric, false);

    let img = document.createElement('img');
    img.classList.add("task-button");
    img.src=iconpath;
    if(img_id != null){
        img.id = img_id;
    }

    a.appendChild(img);
    menu.appendChild(a);
}


function showMenu(event) {
    const menu = document.getElementById('context-menu');
    menu.style.visibility = 'visible';
    menu.style.left = event.pageX -10 +'px';
    menu.style.top = event.pageY - menu.clientHeight -15 + 'px';

    // Close the menu when clicking outside
    window.addEventListener('click', function(event) {
        if (event.target.classList.contains('mycanvas')) {
            menu.style.visibility = 'hidden';
        }
    });
}


// Hide the context menu when the page loads
window.onload = function() {
    const menu = document.getElementById('context-menu');
    menu.style.visibility = 'hidden';
};



// Fabric.js copy and paste
let _clipboard;
function Copy() {
  // clone what are you copying since you
  // may want copy and paste on different moment.
  // and you do not want the changes happened
  // later to reflect on the copy.
  canvas
    .getActiveObject()
    .clone()
    .then((cloned) => {
      _clipboard = cloned;
    });
}

async function Paste() {
  // clone again, so you can do multiple copies.
  const clonedObj = await _clipboard.clone();
  canvas.discardActiveObject();
  clonedObj.set({
    left: clonedObj.left + 10,
    top: clonedObj.top + 10,
    evented: true,
  });
  if (clonedObj instanceof fabric.ActiveSelection) {
    // active selection needs a reference to the canvas.
    clonedObj.canvas = canvas;
    clonedObj.forEachObject((obj) => {
      canvas.add(obj);
    });
    // this should solve the unselectability
    clonedObj.setCoords();
  } else {
    canvas.add(clonedObj);
  }
  _clipboard.top += 10;
  _clipboard.left += 10;
  canvas.setActiveObject(clonedObj);
  canvas.requestRenderAll();
}

// not using addEventListener to avoid cleanup logic in the demo code
//document.getElementById('copy').onclick = () => Copy();
//document.getElementById('paste').onclick = () => Paste();